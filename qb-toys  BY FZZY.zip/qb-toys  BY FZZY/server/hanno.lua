local QBCore = exports['qb-core']:GetCoreObject() 

function RandomItem()
    return Config.Burgershot[math.random(#Config.Burgershot)]
end

function RandomItemm()
    return Config.Roosterrest[math.random(#Config.Roosterrest)]
end

RegisterNetEvent("GenerateRandomToy")
AddEventHandler("GenerateRandomToy", function(source, item)
	local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    Player.Functions.AddItem(RandomItem(), 1, item.slot)
end)

RegisterNetEvent("GenerateRandomToyy")
AddEventHandler("GenerateRandomToyy", function(source, item)
	local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    Player.Functions.AddItem(RandomItemm(), 1, item.slot)
end)


QBCore.Functions.CreateUseableItem('toy-egg', function(source, item)
	local src = source
    local Player = QBCore.Functions.GetPlayer(src)
	if Player.Functions.RemoveItem(item.name, 1, item.slot) then
        TriggerEvent("GenerateRandomToy", src, item.name)
    end
end)

QBCore.Functions.CreateUseableItem('toy-eggg', function(source, item)
	local src = source
    local Player = QBCore.Functions.GetPlayer(src)
	if Player.Functions.RemoveItem(item.name, 1, item.slot) then
        TriggerEvent("GenerateRandomToyy", src, item.name)
    end
end)