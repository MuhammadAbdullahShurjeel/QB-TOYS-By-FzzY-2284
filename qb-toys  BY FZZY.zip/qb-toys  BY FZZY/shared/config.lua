Config = {}

Config.Burgershot = {
    'barry',
    'lenny',
    'oki',
    'hanno',
    'kiki'
}

Config.Roosterrest = {
    'bjorn',
    'buddha',
    'clayvon',
    'donnie',
    'gloryon',
    'lando',
    'leyla',
    'meowfurryon',
    'stagdancer',
    'sven',
    'yeager'
}
