fx_version 'cerulean'
games { 'gta5' }

-- What to run
client_scripts {
    'client/*.lua'
    --'shared/*.lua'
}
server_script {
    'server/*.lua',
    'shared/*.lua'
}